package com.example.characterrecycler;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.characterrecycler.model.Character;
import com.example.characterrecycler.ui.CharacterAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private CharacterAdapter characterAdapter;
    private List<Character> characterList;
    private List<Character> filteredList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        characterList = new ArrayList<>();
        characterList.add(new Character("Harry Potter", "The main protagonist, an orphaned boy who discovers he is a wizard and attends Hogwarts School of Witchcraft and Wizardry",R.drawable.harry));
        characterList.add(new Character("Hermione Granger", "One of Harry's best friends, known for her intelligence, dedication, and strong moral compass",R.drawable.hermione));
        characterList.add(new Character("Ron Weasley", "Harry's other best friend, loyal and brave, often providing comic relief, and a member of the Weasley family",R.drawable.ron));
        characterList.add(new Character("Albus Dumbledore", "The wise and kind headmaster of Hogwarts, one of the most powerful wizards in history",R.drawable.albus));
        characterList.add(new Character("Severus Snape", "Hogwarts' Potions Master, initially a complex antagonist who later plays a critical role in the fight against Voldemort",R.drawable.severus));
        characterList.add(new Character("Voldemort", "The dark wizard responsible for the deaths of Harry's parents, seeking to conquer the wizarding world.",R.drawable.voldemort));
        characterList.add(new Character("Draco Malfoy", "A student from a wealthy, pure-blood wizarding family who often clashes with Harry and his friends",R.drawable.draco));
        characterList.add(new Character("Luna Lovegood", "A quirky and imaginative student who becomes one of Harry’s allies in the fight against dark forces",R.drawable.luna));
        characterList.add(new Character("Neville Longbottom", "A shy and awkward Gryffindor student who eventually shows great bravery in the final battle against Voldemort",R.drawable.neville));
        characterList.add(new Character("Ginny Weasley", "Ron’s younger sister, a powerful witch who becomes Harry's love interest and plays a pivotal role in the later books",R.drawable.ginny));
        characterList.add(new Character("Minerva McGonagall", "The strict yet fair Transfiguration professor and head of Gryffindor House, a loyal ally to Harry",R.drawable.minerva));
        characterList.add(new Character("Hagrid", "The kind-hearted half-giant Keeper of Keys and Grounds at Hogwarts, who introduces Harry to the wizarding world",R.drawable.hagrid));
        characterList.add(new Character("George & Fred Weasley", "Ron's mischievous twin brothers who start a joke shop and provide both humor and support in the fight against Voldemort",R.drawable.fredandgeorge));
        characterList.add(new Character("Sirius Black", "Harry's godfather, wrongfully imprisoned for a crime he didn’t commit, and a key member of the Order of the Phoenix",R.drawable.sirius));
        characterList.add(new Character("Bellatrix Lestrange", "A fanatically loyal follower of Voldemort, known for her sadistic nature and her role in key battles during the wizarding war",R.drawable.belastrix));

        filteredList = new ArrayList<>(characterList);

        recyclerView = findViewById(R.id.recyclerMain);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        characterAdapter = new CharacterAdapter(this, filteredList);
        recyclerView.setAdapter(characterAdapter);

        EditText searchBox = findViewById(R.id.searchBox);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                filterList(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }
    private void filterList(String query) {
        filteredList.clear();
        for (Character character : characterList) {
            if (character.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(character);
            }
        }
        characterAdapter.notifyDataSetChanged();
    }
}