package com.example.characterrecycler.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.characterrecycler.R;
import com.example.characterrecycler.model.Character;

import java.util.List;

public class CharacterAdapter extends RecyclerView.Adapter<CharacterAdapter.CharacterViewHolder> {
    private Context context;
    private List<Character> characters;

    public CharacterAdapter(Context context, List<Character> characters){
        this.context = context;
        this.characters = characters;
    }

    @NonNull
    @Override
    public CharacterAdapter.CharacterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.character_item, parent, false);
        return new CharacterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CharacterViewHolder holder, int position) {
        Character character = characters.get(position);

        holder.nameTextView.setText(character.getName());
        holder.descriptionTextView.setText(character.getDescription());
        holder.imageView.setImageResource(character.getImage());

        holder.itemView.setOnClickListener(v -> {
            Toast.makeText(context, character.getName() + " " + character.getDescription(), Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return characters.size();
    }

    public void updateList(List<Character> newList) {
        characters = newList;
        notifyDataSetChanged();
    }

    public static class CharacterViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView nameTextView;
        TextView descriptionTextView;

        public CharacterViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.char_image);
            nameTextView = itemView.findViewById(R.id.char_name);
            descriptionTextView = itemView.findViewById(R.id.char_desc);
        }
    }
}
